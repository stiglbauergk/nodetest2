use nodetest2;
db.createCollection("userlist");
db.userlist.insert({'username' : 'stiglbauergk','email'
: 'stiglbauergk@g.cofc.edu','fullname' : 'Grayson Stiglbauer',
'age' : 22,'location' : 'Columbia, SC','gender' : 'Male'});
