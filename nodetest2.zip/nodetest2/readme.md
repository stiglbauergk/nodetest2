# Node App 2


The point of this app is to demonstrate CRUD operations.


## Files

### `package.JSON`

This file holds metadata about the project such as information about the project's identity and dependencies of the project.

### `package-lock.JSON`

This file is an auto-generated file that complements package.json.



This file contains the command-line commands to build the Docker images and run the containers.
 The individual commands may be copied and pasted into a command line or the file will run as a Bash shell script on a Linux of MacOS system.



## Directories


###
adr


This directory contains the Architectural Design Records


###
data

This directory holds data files.

###
node modules
This directory holds the modules used in the app.

###
public
This directory holds the images, global.JS file, and .css file for the app.

###
routes
This directory holds .js files that connect the app to the Express server.

###
views
This directory holds the .jade files used as views in the app.

###
mongodb
This directory contains the files necessary to build the Docker container for the MongoDB database.

###
node
This directory contains the files necessary to build the Docker container for the Node app.


This directory contains the files necessary to build the Wordpress container for the Wordpress content management system.
